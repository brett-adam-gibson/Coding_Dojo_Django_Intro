from django.apps import AppConfig


class NinjaMoneyAppConfig(AppConfig):
    name = 'ninja_money_app'
